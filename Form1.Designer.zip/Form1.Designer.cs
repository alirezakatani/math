﻿namespace math_project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtnumdata = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.txtdata = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtcv = new System.Windows.Forms.TextBox();
            this.txtvarince = new System.Windows.Forms.TextBox();
            this.txtmod = new System.Windows.Forms.TextBox();
            this.txtmiangin = new System.Windows.Forms.TextBox();
            this.txtmiane = new System.Windows.Forms.TextBox();
            this.txtenheraf = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnapply = new System.Windows.Forms.Button();
            this.datalable = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnmohasebe = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnres = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(14, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "data number(click Apply)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtnumdata
            // 
            this.txtnumdata.Location = new System.Drawing.Point(350, 48);
            this.txtnumdata.Margin = new System.Windows.Forms.Padding(5);
            this.txtnumdata.Name = "txtnumdata";
            this.txtnumdata.Size = new System.Drawing.Size(185, 34);
            this.txtnumdata.TabIndex = 1;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(559, 122);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(124, 34);
            this.btnadd.TabIndex = 2;
            this.btnadd.Text = "add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // txtdata
            // 
            this.txtdata.Location = new System.Drawing.Point(350, 124);
            this.txtdata.Name = "txtdata";
            this.txtdata.Size = new System.Drawing.Size(185, 34);
            this.txtdata.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(14, 127);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "inter numbers and click add";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(14, 407);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 29);
            this.label3.TabIndex = 5;
            this.label3.Text = "variance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(14, 220);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "miane";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(14, 349);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 29);
            this.label5.TabIndex = 7;
            this.label5.Text = "mod";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(14, 285);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "maingin";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(14, 464);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 29);
            this.label7.TabIndex = 9;
            this.label7.Text = "C.V";
            // 
            // txtcv
            // 
            this.txtcv.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtcv.Location = new System.Drawing.Point(168, 461);
            this.txtcv.Name = "txtcv";
            this.txtcv.ReadOnly = true;
            this.txtcv.Size = new System.Drawing.Size(185, 34);
            this.txtcv.TabIndex = 11;
            // 
            // txtvarince
            // 
            this.txtvarince.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtvarince.Location = new System.Drawing.Point(168, 407);
            this.txtvarince.Name = "txtvarince";
            this.txtvarince.ReadOnly = true;
            this.txtvarince.Size = new System.Drawing.Size(185, 34);
            this.txtvarince.TabIndex = 12;
            // 
            // txtmod
            // 
            this.txtmod.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtmod.Location = new System.Drawing.Point(168, 346);
            this.txtmod.Name = "txtmod";
            this.txtmod.ReadOnly = true;
            this.txtmod.Size = new System.Drawing.Size(185, 34);
            this.txtmod.TabIndex = 13;
            // 
            // txtmiangin
            // 
            this.txtmiangin.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtmiangin.Location = new System.Drawing.Point(168, 282);
            this.txtmiangin.Name = "txtmiangin";
            this.txtmiangin.ReadOnly = true;
            this.txtmiangin.Size = new System.Drawing.Size(185, 34);
            this.txtmiangin.TabIndex = 14;
            // 
            // txtmiane
            // 
            this.txtmiane.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtmiane.Location = new System.Drawing.Point(168, 225);
            this.txtmiane.Name = "txtmiane";
            this.txtmiane.ReadOnly = true;
            this.txtmiane.Size = new System.Drawing.Size(185, 34);
            this.txtmiane.TabIndex = 15;
            // 
            // txtenheraf
            // 
            this.txtenheraf.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtenheraf.Location = new System.Drawing.Point(192, 512);
            this.txtenheraf.Name = "txtenheraf";
            this.txtenheraf.ReadOnly = true;
            this.txtenheraf.Size = new System.Drawing.Size(161, 34);
            this.txtenheraf.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(5, 512);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(179, 29);
            this.label8.TabIndex = 16;
            this.label8.Text = "enheraf meayar";
            // 
            // btnapply
            // 
            this.btnapply.Location = new System.Drawing.Point(559, 48);
            this.btnapply.Name = "btnapply";
            this.btnapply.Size = new System.Drawing.Size(124, 34);
            this.btnapply.TabIndex = 18;
            this.btnapply.Text = "Apply";
            this.btnapply.UseVisualStyleBackColor = true;
            this.btnapply.Click += new System.EventHandler(this.button1_Click);
            // 
            // datalable
            // 
            this.datalable.AutoSize = true;
            this.datalable.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.datalable.Location = new System.Drawing.Point(688, 21);
            this.datalable.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.datalable.Name = "datalable";
            this.datalable.Size = new System.Drawing.Size(128, 29);
            this.datalable.TabIndex = 19;
            this.datalable.Text = "data value:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1-gosaste",
            "2-peyvaste"});
            this.comboBox1.Location = new System.Drawing.Point(559, 255);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 37);
            this.comboBox1.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(386, 258);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 29);
            this.label9.TabIndex = 23;
            this.label9.Text = "data type";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(765, 186);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(821, 365);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnmohasebe
            // 
            this.btnmohasebe.Enabled = false;
            this.btnmohasebe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnmohasebe.Location = new System.Drawing.Point(559, 162);
            this.btnmohasebe.Name = "btnmohasebe";
            this.btnmohasebe.Size = new System.Drawing.Size(124, 34);
            this.btnmohasebe.TabIndex = 26;
            this.btnmohasebe.Text = "mohasebe";
            this.btnmohasebe.UseVisualStyleBackColor = true;
            this.btnmohasebe.Click += new System.EventHandler(this.button3_Click);
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btndelete.Location = new System.Drawing.Point(559, 202);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(124, 34);
            this.btndelete.TabIndex = 27;
            this.btndelete.Text = "DeleteAll";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnres
            // 
            this.btnres.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnres.Location = new System.Drawing.Point(391, 329);
            this.btnres.Name = "btnres";
            this.btnres.Size = new System.Drawing.Size(124, 34);
            this.btnres.TabIndex = 28;
            this.btnres.Text = "AppRestart";
            this.btnres.UseVisualStyleBackColor = true;
            this.btnres.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1652, 569);
            this.Controls.Add(this.btnres);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnmohasebe);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.datalable);
            this.Controls.Add(this.btnapply);
            this.Controls.Add(this.txtenheraf);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtmiane);
            this.Controls.Add(this.txtmiangin);
            this.Controls.Add(this.txtmod);
            this.Controls.Add(this.txtvarince);
            this.Controls.Add(this.txtcv);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtdata);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtnumdata);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnumdata;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox txtdata;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtcv;
        private System.Windows.Forms.TextBox txtvarince;
        private System.Windows.Forms.TextBox txtmod;
        private System.Windows.Forms.TextBox txtmiangin;
        private System.Windows.Forms.TextBox txtmiane;
        private System.Windows.Forms.TextBox txtenheraf;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnapply;
        private System.Windows.Forms.Label datalable;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnmohasebe;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnres;
    }
}

