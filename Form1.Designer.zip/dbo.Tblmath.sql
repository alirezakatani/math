﻿CREATE TABLE [dbo].[Tblmath] (
    [Radeha]         NVARCHAR (100) NOT NULL,
    [Xi(nemayandeh)] NVARCHAR (100) NOT NULL,
    [fi]             NVARCHAR (100) NOT NULL,
    [Gi]             NVARCHAR (100) NOT NULL,
    [Ri]             NVARCHAR (100) NOT NULL,
    [Si]             NVARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([Radeha])
);

